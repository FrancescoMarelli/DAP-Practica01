package shapes;
import java.awt.*;

public class MySquare extends MyRectangle {

    public MySquare(int x, int y, double width, Color color) {
        super(x, y, width, width, color);
    }
}
